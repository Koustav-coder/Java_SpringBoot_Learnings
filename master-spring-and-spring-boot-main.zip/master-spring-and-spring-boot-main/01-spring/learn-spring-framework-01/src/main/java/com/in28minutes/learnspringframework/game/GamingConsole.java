package com.in28minutes.learnspringframework.game;

public interface GamingConsole {
	void up();
	void down();
	void left();
	void right();
}
